package atm.factory;

import atm.platform.StorageAdapter;

public class StorageAdapterFactory {
    public static StorageAdapter getStorageAdapterInstance(String type) {
        // read from config and return the relevant adapter
        return null;
    }
}
