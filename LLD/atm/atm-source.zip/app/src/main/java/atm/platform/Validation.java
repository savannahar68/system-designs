package atm.platform;

public interface Validation {
    //
}
