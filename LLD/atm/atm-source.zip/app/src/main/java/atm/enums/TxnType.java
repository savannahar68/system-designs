package atm.enums;

public enum TxnType {
    DIPOSITE,
    WITHDRAWAL;
}
