package atm.enums;

public enum TxnStatus {
    INPROGRESS,
    COMPLETED,
    CANCELLED,
    FAILED;
}
