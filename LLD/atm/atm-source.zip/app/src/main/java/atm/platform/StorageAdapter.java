package atm.platform;

public interface StorageAdapter {
}
