package atm.adapter;

import atm.platform.StorageAdapter;

public class StorageAdapterImpl implements StorageAdapter {
}
