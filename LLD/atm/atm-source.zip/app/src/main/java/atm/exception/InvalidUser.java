package atm.exception;

public class InvalidUser extends Throwable {
}
