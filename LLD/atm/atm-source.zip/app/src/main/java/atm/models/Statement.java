package atm.models;

import java.util.List;

public class Statement {
    List<Transaction> transactionList;
}
