package atm.factory;

import atm.platform.Validation;

public class ValidationFactory {
    public static Validation getValidationInstance(String type) {
        // read from the config map
        return null;
    }
}
