package navi.vehicle.rental.lld;

public class SimplePricingStrategyTest {
}
