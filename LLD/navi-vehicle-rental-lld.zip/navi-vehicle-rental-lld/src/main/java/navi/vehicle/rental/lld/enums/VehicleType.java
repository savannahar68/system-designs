package navi.vehicle.rental.lld.enums;

public enum VehicleType {
    CAR,
    VAN,
    TRUCK,
    MOTORCYCLE,
    BUS,
    BIKE,
    OTHER;
}
