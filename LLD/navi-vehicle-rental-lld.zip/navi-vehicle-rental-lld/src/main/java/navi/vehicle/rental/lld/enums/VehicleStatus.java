package navi.vehicle.rental.lld.enums;

public enum VehicleStatus {
    AVAILABLE,
    RENTED,
    NOT_AVAILABLE;
}
