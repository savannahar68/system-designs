# navi-vehicle-rental-lld
Vehicle Rental Service LLD

Run app.java to start the service and pass the absolute Path of file having Rent service test cases.


Sample input file: navi-vehicle-rental-lld/src/main/resources/Sample.txt
